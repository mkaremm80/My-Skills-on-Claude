"""Put \\Needspace{N\\baselineskip} before every \\section (avoids headings alone at the bottom of a page).

    python3 needspace_pass.py survey.tex        # N = 14, edits in place; safe to run twice
    python3 needspace_pass.py survey.tex 20     # custom N
Headings followed by a big table or figure may need a larger value (up to 30): edit those by hand.
"""
import sys

p = sys.argv[1]
n = int(sys.argv[2]) if len(sys.argv) > 2 else 14
lines = open(p, encoding="utf-8").read().split("\n")
out = []
for ln in lines:
    if ln.lstrip().startswith("\\section") and not (out and out[-1].strip().startswith("\\Needspace")):
        out.append("\\Needspace{%d\\baselineskip}" % n)
    out.append(ln)
s = "\n".join(out)
open(p, "w", encoding="utf-8").write(s)
print("done:", s.count("\\Needspace{"), "Needspace commands")
